
public class Strings
{
	public static final String IS_IT_ALIVE = "Is it alive?";
	public static final String ROCK = "Rock";
	public static final String DUCK = "Duck";
	public static final String PLAY_AGAIN = "Do you want to play again?";
	
	public static final String NEW_QUESTION = "Please provide me a question that will differentiate between a ";
	public static final String WHAT_IS_THE_ANSWER = "Oh dear, what is the answer?";
	public static final String I_WIN = "Ha Ha, I win!";
	public static final String IS_IT_A = "Is it a ";
	public static final String THANKS = "Thanks!";
}
